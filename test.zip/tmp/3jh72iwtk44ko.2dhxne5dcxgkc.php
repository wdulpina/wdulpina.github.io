<!-- Fonts -->
    	<!-- Open Sans -->
    	<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400italic,600,700italic,400,700,800italic" rel="stylesheet" type="text/css">
    	<!-- VarelaRound -->
    	<link href="http://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet" type="text/css">
    	<!-- Icon Font - Font Awesome -->
	<!-- Stylesheets -->
		<!-- Mobile nav -->
		<link href="/asset/external/z-nav/z-nav.css" rel="stylesheet" type="text/css">
        <link href="/asset/external/animated-header/css/component.css" rel="stylesheet" type="text/css">
        <!-- Magnific popup - responsive popup plugin -->
        <link href="/asset/external/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css">
        <link href="/asset/external/tabs/tabs.css" rel="stylesheet" type="text/css">
        <link href="/asset/external/tabs/tabstyles.css" rel="stylesheet" type="text/css">
        <!-- Blueberry Slider -->
        <link href="/asset/external/blueberry-master/blueberry.css">		
		<!-- Custom -->
        <link href="/asset/css/stylelogin.css" rel="stylesheet" type="text/css"> 

        <!--[if IE]><link rel="icon"  href="../images/favicon-allec.ico" /><![endif]-->
        <link rel="icon" href="/web/LOGO/lee.ico" type="image/x-icon" />
        <!-- Specifying a Webpage Icon for Web Clip -->
        <link rel="icon" href="/web/LOGO/lee.ico" type="image/x-icon" />
        <!-- Modernizr -->


    
    <div id="page" class="page wrapper"><div class="block-top" id="header-4">
      <!-- Header section -->
      <header class="header header--social">
        <div class="header-fixed bg-color">
          <div class="header-line waypoint" data-animate-down="header-up" data-animate-up="header-down">
            <div class="container">
              <!-- Contact information about company -->
              <address class="contact-info pull-left hidden-lower">
                <span class="contact-info__item">
                            <i class="fa fa-mobile"></i>
                            <span class="editContent text">
                            09062758260
                            </span>
                </span>
                <span class="contact-info__item">
                            <i class="fa fa-envelope"></i>
                            <span class="editContent text">
                            wengski023@gmail.com
                            </span>
                </span>
              </address>
              <!-- end contact information -->
              <div class="social social--default social--small">
                <!-- List with social icons -->
                <ul>
                  <li class="social__item"><a class="social__link bg-color" href="#"><i class="social__icon fa fa-paper-plane"></i></a></li>
                  <li class="social__item"><a class="social__link bg-color" href="https://facebook.com/ByteHAX"><i class="social__icon fa fa-facebook"></i></a></li>
                  <li class="social__item"><a class="social__link bg-color" href="#"><i class="social__icon fa fa-youtube-play"></i></a></li>
                 <li class="social__item"><a class="social__link bg-color" href="https://bytehax.blogspot.com/p/contact.html"><i class="social__icon fa fa-envelope"></i></a></li>
                </ul>
              </div>
            </div>
            <!-- end container -->
          </div>
          <div class="fixed-top header-down bg-color">
            <div class="container">
              <!--  Logo  -->
              <a class="logo" href="web/register.html">
                <!-- Remove comments to choose image and add comment to h1 -->
                <!--<img src="images/logo-full.png" alt="">-->
                <svg class="logo__svg" width="32" height="32" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg" >
                  <g>
                    <path class="logo__svg-path" d="m18.8,14c-1.2,-0.2 -2.3,0.1 -3.2,0.6c-0.8,0.5 -1.8,0.2 -2.4,-0.7c-0.4,-0.8 -0.2,-1.8 0.7,-2.3c1.4,-0.7 3,-1.2 4.7,-1.1c-0.2,-0.1 -0.4,-0.2 -0.6,-0.4c-0.8,-0.7 -1.8,-1.3 -3,-1.4c-2.6,-0.3 -5.1,1.5 -5.4,4s1.6,4.9 4.2,5.2c1.2,0.1 2.3,-0.1 3.2,-0.6c0.8,-0.5 1.8,-0.2 2.4,0.7c0.4,0.8 0.2,1.8 -0.7,2.3c-1.3,0.7 -3,1.2 -4.7,1.1c0.2,0.1 0.4,0.2 0.6,0.4c0.8,0.7 1.8,1.3 3,1.4c2.6,0.3 5.1,-1.5 5.4,-4c0.4,-2.4 -1.5,-4.8 -4.2,-5.2zm-2.8,-14c-8.8,0 -16,7.2 -16,16s7.2,16 16,16c8.8,0 16,-7.2 16,-16s-7.2,-16 -16,-16zm10.5,19.7c-0.6,4.5 -4.8,7.5 -9.4,7c-2,-0.3 -3.7,-1.2 -4.9,-2.4c-0.7,-0.7 -0.7,-1.8 0,-2.4c0.3,-0.3 0.7,-0.4 1,-0.5c-4.4,-0.6 -7.6,-4.7 -7.1,-9c0.6,-4.5 4.8,-7.5 9.3,-7c2,0.2 3.7,1.2 5,2.4c0.7,0.7 0.7,1.8 0,2.4c-0.3,0.3 -0.7,0.4 -1,0.5c4.5,0.6 7.7,4.6 7.1,9z" fill="#fff21f">
                  </path></g>
                </svg>
                <h1 class="logo__text editContent" style="outline: medium none; cursor: inherit;">SSH &amp; VPN</h1>
              </a>
              <!-- End Logo -->
              <!-- Navigation section -->
              <nav class="z-nav">
                <!-- Toggle for menu mobile view -->
                <a href="" class="z-nav__toggle">
                  <span class="menu-icon"></span>
                  <span class="menu-text">navigation</span>
                  <div class="menu-head"></div>
                </a>
                <ul class="z-nav__list">
                  <li class="z-nav__item">
                    <a class="z-nav__link editContent z-nav__link--active" href="">Home</a>
                  </li>
                  <li class="z-nav__item">
                    <a class="z-nav__link editContent" href="web/register.html">Register</a>
                  </li>        
                </ul>
                <!-- end list menu item -->
              </nav>
              <!-- end navigation section -->
            </div>
            <!-- end container -->
            <!-- Colored devider -->
            <div class="devider-color"></div>
          </div>
          <!-- end fixed top block -->
        </div>
      </header>
    </div>
<div class="login-box-body">	
<section class="content">	
	<div class="space space--lg">
	</div>

		<div class="block" id="feature2">
            <div class="container">
                <div class="row">
                    <div class="col-md-6"><br>
                        <h2 class="block-title block-title--left editContent">Panel Reseller Features<span class="block-title-color bg-color"></span></h2>

<ul class="list list--ckeck text-list" style="color: #660404">
                    <li>SSH &amp; VPN premium with the best quality and fastest connection...</li>
                    <li>Available server Singapore...</li>
                    <li>Affordable price for all servers...</li>
                    <li>SSH &amp; VPN, Dropbear, Squid, Nginx, Privoxy...</li>
                </ul>
                    </div><!-- end col -->
                <div>
            </div>
                    <div class="col-md-6">
                        <h2 class="block-title block-title--left editContent">Members Login<span class="block-title-color bg-color"></span></h2>
                <?php if ($message): ?>
                    <div class="alert alert-<?php echo $message['type']; ?>"><?php echo $message['data']; ?></div>
                <?php endif; ?>
                <div class="login">
   <form action="/login" method="post">
     <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                        <input required="required" id="username" type="text" class="form-control" name="username" value="" placeholder="Username">                                        
                                        </div>
                                         <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                        <input required="required" id="password" type="password" class="form-control" name="password" placeholder="Password">
                                     </div>                                                                 
                                    <div style="margin-top:15px" class="form-group">
                                    <!-- Button -->
                                    <div class="col-lg-12">
                                      <span ></span>
                                     <input  type="submit" value=" LOGIN " name="submit" class="btn btn-success"> &nbsp;&nbsp;&nbsp;&nbsp; ( For members only )
                                    </div><br>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12 control">
                                        <div style="border-top: 1px solid#888; padding-top:15px; font-size:85%" >
                                            Don't have an account? 
                                        <a href="https://telegram.me/LeeDzung">&nbsp;&nbsp;
                                            Find re-seller here
                                        </a>
                                        </div>
                                    </div>
                                </div>    
    </form>
                </div>
                    </div><!-- end col -->
            </div><!-- end row -->
            </div> </div>
	   	
    	<div class="space space--lg">   
        
             </div><!-- /#page -->
   </section> 
   
   </div>      
 
  <footer>  
    <div class="block-bottom" id="footer-6">
            <!-- Colored devider -->
            <div class="devider-color"></div>
            <!-- Footer section -->
            <footer class="footer footer--simple bg-color">
                <div class="container">
                    <ul class="navigation navigation--add">
                    <li><a href="http://www.youtube.com/c/JohnFordTV" class="editContent">Copyright &copy; JohnFordTV</a></li>
                        <li><a href="/web/rules.html" class="editContent">Server Rules</a></li>
                        <li><a href="/web/terms.html" class="editContent">Terms and conditions</a></li>
                    </ul> </div>
           <!-- end container -->
            </footer>
            <!-- end footer section -->
       


		
		


<script type="text/javascript" src="/asset/external/waypoint/waypoints.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script type="text/javascript" src="/asset/external/modernizr/modernizr.custom.js"></script>
<script type="text/javascript" src="/asset/external/z-nav/jquery.mobile.menu.js"></script>
<script type="text/javascript" src="/asset/js/custom.js"></script>
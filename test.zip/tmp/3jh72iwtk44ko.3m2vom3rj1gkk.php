  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
  <?php if ($seller->id): ?>
  
    <section class="content-header">   
                    <h1>
                        Edit Seller
                     
                          </h1>
      <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="/home/admin/seller">List Seller</a></li>
        <li class="active">Edit Seller</li>
      </ol>
    </section>
					
                    <?php else: ?>
                        <section class="content-header">   
                    <h1>
                        Add Seller
						                          </h1>
      <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="/home/admin/seller">List Seller</a></li>
        <li class="active">Add Seller</li>
      </ol>
    </section>
                    
            <?php endif; ?>

    <!-- Main content -->
    <section class="content">
	        <?php if ($message): ?>     
				<div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>
			
		<div class="row">
        <div class="col-md-6">	
			         <div class="box box-primary">
            <div class="box-header with-border">
               <i class="fa fa-user fa-fw"></i><h3 class="box-title">Seller Account</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->

            <form role="form" action="<?php echo $URI; ?>" method="POST">
              <div class="box-body">
              			<div class="form-group">
                            <label>Email</label>
                            <input class="form-control" placeholder="Email" name="email" type="text" value="<?php echo $seller->email; ?>" required>
                        </div>
						<div class="form-group">
                            <label>First name</label>
                            <input class="form-control" placeholder="First name" name="firstname" type="text" value="<?php echo $seller->firstname; ?>" required>
                        </div>
						<div class="form-group">
                            <label>Last name</label>
                            <input class="form-control" placeholder="Last name" name="lastname" type="text" value="<?php echo $seller->lastname; ?>" required>
                        </div>
                         <div class="form-group">
                            <label>Username</label>
                            <input class="form-control" placeholder="Username" name="username" type="text" value="<?php echo $seller->username; ?>" required>
                        </div>
                        <?php if (!$seller->id): ?>
                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" placeholder="New Password" name="password" type="password" required>
                            </div>
                            <div class="form-group">
                                <label>Re-enter Password</label>
                                <input class="form-control" placeholder="Re-enter Password" name="password_confirmation" type="password" required>
                            </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <label>Balance</label>
                            <div class="input-group">
                                <span class="input-group-addon">PHP </span>
                                <input class="form-control" placeholder="100" name="saldo" type="number" step="1" value="<?php echo $seller->saldo; ?>" required>
                            </div>
                        </div>
						
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Save</button>
                        <?php if ($seller->id): ?>
                            
                                <?php if ($seller->active==1): ?>
                                    
                                        <a href="<?php echo $URI.'/active/0'; ?>" class="btn btn-warning">Locked</a>
                                    
                                    <?php else: ?>
                                        <a href="<?php echo $URI.'/active/1'; ?>" class="btn btn-success">Unlocked</a>
                                    
                                <?php endif; ?>
                                <a href="<?php echo $URI.'/delete'; ?>" class="btn btn-danger hapus">Delete</a>
                            
                            <?php else: ?>
                                <a href="/home/admin/seller" class="btn btn-default">Back</a>
                            
                        <?php endif; ?>
				              </div>
            </form>
          </div>
          <!-- /.box -->
          </div>

       <?php if ($seller->id): ?>		  
        <div class="col-md-6">		  
         <div class="box box-danger">
            <div class="box-header with-border">
               <i class="fa fa-cog fa-spin"></i><h3 class="box-title">Change Password</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="<?php echo $URI; ?>" method="POST">
              <div class="box-body">
                        <div class="form-group">
                            <label>New Password</label>
                            <input class="form-control" placeholder="New Password" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>Re-enter New Password</label>
                            <input class="form-control" placeholder="Re-enter New Password" name="password_confirmation" type="password" required>
                        </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Save</button>
              <a href="/home/admin/seller" class="btn btn-default pull-right"><i class="fa fa-arrow-left fa-fw"></i> Back</a>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
<?php endif; ?>
		  
          </div>		  
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        User Profile
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Profile</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
	
     <div class="row">
        <div class="col-md-4">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="http://i.imgur.com/TbL3fe6.png" alt="User profile picture">

              <h3 class="profile-username text-center"><?php echo $me->firstname; ?> <?php echo $me->lastname; ?></h3>

              <p class="text-muted text-center"><?php echo $me->type==1?'Admin':'Reseller'; ?></p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Username</b> <a class="pull-right"><?php echo $me->username; ?></a>
                </li>
                <li class="list-group-item">
                  <b>Email</b> <a class="pull-right"><?php echo $me->email; ?></a>
                </li>
                <li class="list-group-item">
                  <b>Balance</b> <a class="pull-right"><?php echo $me->saldo; ?></a>
                </li>
              </ul>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
		
	 <div class="col-md-8">
	        <?php if ($message): ?>     
				<div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-warning"></i>Alert!</h4>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>
		
         <div class="box box-danger">
            <div class="box-header with-border">
               <i class="fa fa-cog fa-spin"></i><h3 class="box-title">Change Password</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="<?php echo $URI; ?>" method="POST">
              <div class="box-body">
                        <div class="form-group">
                            <label>Old Password</label>
                            <input class="form-control" placeholder="Old Password" name="oldpass" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <input class="form-control" placeholder="New Password" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>Re-enter New Password</label>
                            <input class="form-control" placeholder="Re-enter New Password" name="password_confirmation" type="password" required>
                        </div>
                     </div>&nbsp;&nbsp;
            <button type="submit" class="btn btn-primary fa fa-cubes"> CHANGE</button> 
              <!-- /.box-body -->
</form>
              <div class="box-footer">
               
              </div>
           
         </div>
          <!-- /.box -->
		</div>
     

    </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
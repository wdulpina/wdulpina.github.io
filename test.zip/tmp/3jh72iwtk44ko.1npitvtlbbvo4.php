<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="#" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>S</b>SH</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>VPN Panel</b></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">

		
		
		
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="http://i.imgur.com/TbL3fe6.png" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo $me->username; ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="http://i.imgur.com/TbL3fe6.png" class="img-circle" alt="User Image">

                <p>
                  <?php echo $me->firstname; ?> <?php echo $me->lastname; ?>
                  <small>Email: <?php echo $me->email; ?></small>
				  <small>Balance: <?php echo $me->saldo; ?></small>
                </p>
              </li>
              <!-- Menu Body -->
              <li class="user-body">
                <div class="row">
                </div>
                <!-- /.row -->
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="/home/setting" class="btn btn-default btn-flat fa fa-cogs"> Setting</a>
                </div>
                <div class="pull-right">
                  <a href="/logout"  class="btn btn-default btn-flat fa fa-sign-out" > Log out</a>
                </div>
              </li>
            </ul>
          </li>
		  <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="http://i.imgur.com/TbL3fe6.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo $me->username; ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> <?php echo $me->type==1?'Admin':'Reseller'; ?></a>
        </div>
      </div>
      <!-- search form -->

      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MAIN MENU</li>
        <li><a href="/home"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
                    <?php if ($me->type==1): ?>
                        
					
        <li class="treeview">
          <a href="#">
            <i class="fa fa-server"></i> <span>Server</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="/home/admin/server"><i class="fa fa-circle-o text-red"></i> List Server</a></li>
            <li><a href="/home/admin/server/add"><i class="fa fa-circle-o text-aqua"></i> Add Server</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-group"></i> <span>Seller</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="/home/admin/seller"><i class="fa fa-circle-o text-red"></i> List Seller</a></li>
            <li><a href="/home/admin/seller/add"><i class="fa fa-circle-o text-aqua"></i> Add Seller</a></li>
          </ul>
        </li>
         <li class="treeview">
          <a href="#">
            <i class="glyphicon glyphicon-user"></i> <span>User</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="/home/admin/server"><i class="fa fa-circle-o text-red"></i> List User</a></li>
            <li><a href="/home/admin/server"><i class="fa fa-circle-o text-aqua"></i> Add User</a></li>
          </ul>
        </li>  
         <li class="treeview">
          <a href="#">
            <i class="fa fa-download fa-fw"></i> <span>Download</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="/web/app.apk"><i class="fa fa-circle-o text-red"></i> Download APK</a></li>
            <li><a href="/web/download.html"><i class="fa fa-circle-o text-aqua"></i> Download Config</a></li>
          </ul>
        </li>                        
		
		<?php else: ?>
        <li><a href="/home/member/server"><i class="fa fa-shopping-cart"></i> <span>Buy SSH &amp; VPN</span></a></li>
        <li><a href="/web/trial.html"><i class="glyphicon glyphicon-eye-close"></i> <span>SSH &amp; VPN Trial</span></a></li>
        <li><a href="/web/app.apk"><i class="fa fa-arrow-circle-down"></i> Download APK</a></li>
        <li><a href="/web/download.html"><i class="fa fa-download fa-fw"></i> <span>Download Config</span></a></li>
        <li><a href="/web/payment.html"><i class="glyphicon glyphicon-usd"></i> <span>Add Deposit</span></a></li>
        <li><a href="/web/register.html"><i class="fa fa-pencil"></i> <span>Register Seller</span></a></li>        
        
        <?php endif; ?>		
        <li class="header">TOOLS</li>
         <li class="treeview">
          <a href="#">
            <i class="glyphicon glyphicon-phone"></i> <span>Contacts</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
        <li><a href="http://facebook.com/143Clarkz"><i class="fa fa-facebook"></i> <span>Facebook</span></a></li>
        <li><a href="#"><i class="fa fa-paper-plane"></i> <span>Telegram</span></a></li>
        <li><a href="https://bytehax@gmail.com"><i class="fa fa-envelope"></i> <span>Gmail</span></a></li>
        <li><a href=""><i class="fa fa-whatsapp"></i> <span>00000000</span></a></li>
          </ul>
         <li class="treeview">
          <a href="#">
            <i class="glyphicon glyphicon-tags"></i> <span>Other</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
        <li><a href="/web/rules.html"><i class="fa fa-exclamation-triangle"></i> <span>Server Rules</span></a></li>
        <li><a href="/web/terms.html"><i class="fa fa-bolt"></i> <span>Terms and conditions</span></a></li>
          </ul>
        </li>                        
        <li><a href="/home/setting"><i class="glyphicon glyphicon-wrench"></i> <span>Setting</span></a></li>
        <li><a href="/logout" ><i class=" fa fa-sign-out" ></i><span>Log out</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <?php echo $this->render($subcontent,$this->mime,get_defined_vars()); ?> 
  

  <footer class="main-footer">
    <strong> &nbsp;&nbsp;Copyright &copy; 2017 <a href="http://bytehax.blogspot.com/">ByteHAX</a>.</strong> All rights
    reserved.
  </footer>

  <aside class="control-sidebar control-sidebar-dark">
      <table id="layout-skins-list" class="table nth-2-center">
        <thead>
          <tr>
            <th style="width: 200px;">Skin Setting</th>
            <th>Preview</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><code>Blue</code></td>
            <td><a href="#" data-skin="skin-blue" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Blue light</code></td>
            <td><a href="#" data-skin="skin-blue-light" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Yellow</code></td>
            <td><a href="#" data-skin="skin-yellow" class="btn btn-warning btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Yellow light</code></td>
            <td><a href="#" data-skin="skin-yellow-light" class="btn btn-warning btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Green</code></td>
            <td><a href="#" data-skin="skin-green" class="btn btn-success btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Green light</code></td>
            <td><a href="#" data-skin="skin-green-light" class="btn btn-success btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Purple</code></td>
            <td><a href="#" data-skin="skin-purple" class="btn bg-purple btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Purple light</code></td>
            <td><a href="#" data-skin="skin-purple-light" class="btn bg-purple btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Red</code></td>
            <td><a href="#" data-skin="skin-red" class="btn btn-danger btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Red light</code></td>
            <td><a href="#" data-skin="skin-red-light" class="btn btn-danger btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Black</code></td>
            <td><a href="#" data-skin="skin-black" class="btn bg-black btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
          <tr>
            <td><code>Black light</code></td>
            <td><a href="#" data-skin="skin-black-light" class="btn bg-black btn-xs"><i class="fa fa-eye"></i></a></td>
          </tr>
        </tbody>
      </table>

  
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
  
</div>
<!-- ./wrapper -->

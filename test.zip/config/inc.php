<?php die();
[globals]
DEBUG=0
AUTOLOAD="controller/;model/"
UI="view/"
APP_KEY="c97e1de7b87d63793f4b058e5a55ad0e154d168b21f5534edd3e57b2129e3d39"
DB_SET="mysql:host=localhost;port=3306;dbname=SKETCHVPN_PANEL"
DB_USER="root"
DB_PASS="phslicer"
?>